# Gift-Shop-Website-
HTML and CSS project to create sample gift shop website.

This is a academic project that I had done in 3rd semester after completing HTML and CSS course 
